<?php
// login.php

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', 'root', 'css326_entity');

if ($conn->connect_errno) {
    echo json_encode(['status' => 'error', 'message' => "Database Connection Failed: " . $conn->connect_error]);
    exit;
}

if (!isset($_POST['email'], $_POST['password'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing email or password.']);
    exit;
}

$email = $_POST['email'];
$password = $_POST['password'];

// UPDATED: Added 'points' to the query
$sql = $conn->prepare("SELECT user_id, first_name, last_name, email, password, role, points FROM users WHERE email = ?");
if (!$sql) {
    echo json_encode(['status' => 'error', 'message' => 'Error preparing statement: ' . $conn->error]);
    $conn->close();
    exit;
}

$sql->bind_param("s", $email);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Email not found.']);
    $sql->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user['password'])) {
    echo json_encode(['status' => 'error', 'message' => 'Incorrect password.']);
    $sql->close();
    $conn->close();
    exit;
}

// Success: Send all user data back as JSON
echo json_encode([
    'status' => 'success',
    'message' => 'Login successful! Welcome, ' . $user['first_name'],
    'user_id' => $user['user_id'],
    'fname' => $user['first_name'],
    'role' => $user['role'],
    'points' => (int)$user['points'] // <-- UPDATED: Send points to JS
]);

$sql->close();
$conn->close();
?>