<?php

    error_reporting(E_ALL);
    ini_set('display_errors', 1);

   
    $conn = new mysqli('localhost', 'root', 'root', 'css326_entity');
    
    if ($conn->connect_errno) {
       
        echo "Database Connection Failed: " . $conn->connect_errno . ": " . $conn->connect_error;
        exit;
    }


    if (!isset($_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['password'])) {
        echo "Error: Missing required fields.";
        exit;
    }

    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $hashed = password_hash($password, PASSWORD_DEFAULT);

 
    $check = $conn->prepare("SELECT email FROM users WHERE email = ?");
    if (!$check) {
        echo "Error preparing check statement: " . $conn->error;
        $conn->close();
        exit;
    }
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "Email already in use.";
        $check->close();
        $conn->close();
        exit;
    }
    $check->close();


    $sql = $conn->prepare("INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
    if (!$sql) {
        echo "Error preparing insert statement: " . $conn->error;
        $conn->close();
        exit;
    }
    $sql->bind_param("ssss", $fname, $lname, $email, $hashed);

    if ($sql->execute()) {
        echo "Signup successful!";
    } else {
        echo "Error executing insert: " . $sql->error;
    }
    
    $sql->close();
    $conn->close();
?>