// admin.js (Complete File)

// --- Page Navigation ---
function showPage(pageId) {
    document.querySelectorAll(".page-section").forEach(sec => {
        sec.classList.remove("active");
    });
    const target = document.getElementById(pageId);
    if(target) target.classList.add("active");

    // NEW: Load data when page is shown
    // This way, data is fresh every time you click a link
    switch (pageId) {
        case 'menu':
            loadMenu();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'users':
            loadUsers();
            break;
        case 'coupons':
            loadCoupons();
            break;
        case 'stock':
            loadStock();
            break;
    }
}

// --- Load Menu Page ---
function loadMenu() {
    const menuList = document.getElementById("menuList");
    menuList.innerHTML = "<p>Loading...</p>";

    fetch("backend/get_items.php")
        .then(res => res.json())
        .then(items => {
            menuList.innerHTML = "";
            if (items.length === 0) {
                menuList.innerHTML = "<p>No items found.</p>";
                return;
            }
            items.forEach(item => {
                // Use default empty string if null, and escape quotes
                const safeName = (item.name || '').replace(/'/g, "\\'");
                const safeCategory = (item.category || '').replace(/'/g, "\\'");
                
                menuList.innerHTML += `
                    <div class="admin-card">
                        <div>
                            <h3>${item.name}</h3>
                            <p>Category: ${item.category || 'N/A'}</p>
                            <p>Price: ${item.price}฿</p>
                            <p>Stock: ${item.stock_quantity}</p>
                            <p>Status: ${item.status}</p>
                        </div>
                        <img src="${item.image ?? 'default.png'}" style="width:80px; height:80px; object-fit:cover;">
                        <div class="admin-actions">
                            <button class="edit-btn"
                                onclick="openEditItem(
                                    ${item.item_id},
                                    '${safeName}',
                                    '${safeCategory}',
                                    ${item.price},
                                    ${item.stock_quantity},
                                    '${item.status}'
                                )">Edit</button>
                            <button class="delete-btn"
                                onclick="deleteItem(${item.item_id})">
                                Delete
                            </button>
                        </div>
                    </div>`;
            });
        })
        .catch(err => {
            console.error("Error loading menu:", err);
            menuList.innerHTML = "<p>Error loading menu items.</p>";
        });
}

// --- Menu Add/Edit/Delete Functions ---

// Add Item
function openAddItem() {
    // Clear form
    document.getElementById('add-name').value = '';
    document.getElementById('add-category').value = '';
    document.getElementById('add-price').value = '';
    document.getElementById('add-stock').value = '';
    document.getElementById('add-status').value = 'Available';
    document.getElementById('addModal').style.display = "block";
}
function closeAddModal() {
    document.getElementById('addModal').style.display = "none";
}
function saveNewItem() {
    const name = document.getElementById('add-name').value;
    const category = document.getElementById('add-category').value;
    const price = document.getElementById('add-price').value;
    const stock = document.getElementById('add-stock').value;
    const status = document.getElementById('add-status').value;

    fetch("backend/add_item.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `name=${encodeURIComponent(name)}&category=${encodeURIComponent(category)}&price=${price}&stock=${stock}&status=${encodeURIComponent(status)}`
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        closeAddModal();
        loadMenu(); // Refresh menu list
    });
}

// Edit Item
function openEditItem(id, name, category, price, stock, status) {
    document.getElementById('edit-id').value = id;
    document.getElementById('edit-name').value = name;
    document.getElementById('edit-category').value = category;
    document.getElementById('edit-price').value = price;
    document.getElementById('edit-stock').value = stock;
    document.getElementById('edit-status').value = status;
    document.getElementById('editModal').style.display = "block";
}
function closeEditModal() {
    document.getElementById('editModal').style.display = "none";
}
function saveEditItem() {
    const id = document.getElementById('edit-id').value;
    const name = document.getElementById('edit-name').value;
    const category = document.getElementById('edit-category').value;
    const price = document.getElementById('edit-price').value;
    const stock = document.getElementById('edit-stock').value;
    const status = document.getElementById('edit-status').value;

    fetch("backend/update_item.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `id=${id}&name=${encodeURIComponent(name)}&category=${encodeURIComponent(category)}&price=${price}&stock=${stock}&status=${encodeURIComponent(status)}`
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        closeEditModal();
        loadMenu(); // Refresh menu list
    });
}

// Delete Item
function deleteItem(id) {
    if (!confirm("Are you sure you want to delete this item?")) return;
    fetch("backend/delete_item.php?id=" + id)
        .then(res => res.text())
        .then(msg => {
            alert(msg);
            loadMenu(); // Refresh menu list
        });
}


// --- NEW: Load Orders Page ---
function loadOrders() {
    const ordersList = document.getElementById("ordersList");
    ordersList.innerHTML = "<p>Loading orders...</p>";

    fetch("backend/get_orders.php")
        .then(res => res.json())
        .then(orders => {
            ordersList.innerHTML = "";
            if (orders.length === 0) {
                ordersList.innerHTML = "<p>No orders found.</p>";
                return;
            }
            orders.forEach(order => {
                const paymentStatus = order.payment_status == 1 ? "Paid" : "Unpaid";
                // This now checks for the text "Complete"
                const orderStatus = order.order_status === "Complete" ? "Complete" : "Pending";
                const orderDate = new Date(order.order_date).toLocaleString('en-GB');

                ordersList.innerHTML += `
                    <div class="order-card">
                        <div class="order-details">
                            <h3>Order #${order.order_id}</h3>
                            <p><strong>User:</strong> ${order.first_name} ${order.last_name}</p>
                            <p><strong>Date:</strong> ${orderDate}</p>
                            <p><strong>Total:</strong> ${order.total_amount}฿</p>
                            <p><strong>Payment:</strong> ${paymentStatus}</p>
                        </div>
                        <div class="order-actions">
                            <p class="order-status ${orderStatus === 'Pending' ? 'status-pending' : 'status-complete'}">
                                ${orderStatus}
                            </p>
                            ${orderStatus === 'Pending' ? `
                                <button class="btn-complete" onclick="updateOrderStatus(${order.order_id}, 1)">
                                    Mark as Complete
                                </button>
                            ` : `
                                <button class="btn-complete disabled" disabled>Completed</button>
                            `}
                        </div>
                    </div>`;
            });
        })
        .catch(err => {
            console.error("Error loading orders:", err);
            ordersList.innerHTML = "<p>Error loading orders.</p>";
        });
}

// --- NEW: Update Order Status ---
function updateOrderStatus(orderId, newStatus) {
    // newStatus is 1 (Complete) from the button click
    if (!confirm("Are you sure you want to mark this order as complete?")) return;

    fetch("backend/update_order_status.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // The backend file (update_order_status.php) now expects text
        // but it's hardcoded to "Complete" so we just send the ID.
        body: JSON.stringify({ order_id: orderId, status: newStatus }) 
    })
    .then(res => res.json())
    .then(result => {
        if (result.status === 'success') {
            alert("Order status updated!");
            loadOrders(); // Refresh the order list
        } else {
            alert("Error: " + result.message);
        }
    });
}

// --- NEW: Load Users Page ---
function loadUsers() {
    const usersList = document.getElementById("usersList");
    usersList.innerHTML = "<p>Loading users...</p>";
    
    fetch("backend/get_users.php")
        .then(res => res.json())
        .then(users => {
            usersList.innerHTML = `
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${users.map(user => `
                            <tr>
                                <td>${user.User_ID}</td>
                                <td>${user.first_name} ${user.last_name}</td>
                                <td>${user.email}</td>
                                <td>${user.role}</td>
                                <td>${user.points}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
        })
        .catch(err => {
            console.error("Error loading users:", err);
            usersList.innerHTML = "<p>Error loading users.</p>";
        });
}

// --- NEW: Load Coupons Page ---
function loadCoupons() {
    const couponList = document.getElementById("couponList");
    couponList.innerHTML = "<p>Loading coupons...</p>";
    
    fetch("backend/get_coupons.php")
        .then(res => res.json())
        .then(coupons => {
            couponList.innerHTML = `
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Owner</th>
                            <th>Discount</th>
                            <th>Expiry</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${coupons.map(coupon => `
                            <tr>
                                <td>${coupon.coupon_code}</td>
                                <td>${coupon.first_name || 'N/A'} ${coupon.last_name || ''}</td>
                                <td>${coupon.discount_amount}฿</td>
                                <td>${new Date(coupon.valid_date).toLocaleDateString('en-GB')}</td>
                                <td>
                                    ${coupon.is_used == 1 ? 
                                        '<span class="status-used">Used</span>' : 
                                        '<span class="status-available">Available</span>'}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
        })
        .catch(err => {
            console.error("Error loading coupons:", err);
            couponList.innerHTML = "<p>Error loading coupons.</p>";
        });
}

// --- NEW: Create Coupon Modal Functions ---
function openCreateCouponModal() {
    // Clear old values
    document.getElementById('create-code').value = '';
    document.getElementById('create-discount').value = '';
    document.getElementById('create-expiry').value = '';
    document.getElementById('createCouponModal').style.display = 'block';
}

function closeCreateCouponModal() {
    document.getElementById('createCouponModal').style.display = 'none';
}

function saveNewCoupon() {
    const code = document.getElementById('create-code').value;
    const discount = document.getElementById('create-discount').value;
    const expiry = document.getElementById('create-expiry').value;

    if (!code || !discount || !expiry) {
        alert('Please fill in all fields.');
        return;
    }

    fetch('backend/create_coupon.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            code: code,
            discount: discount,
            expiry: expiry
        })
    })
    .then(res => res.json())
    .then(result => {
        alert(result.message);
        if (result.status === 'success') {
            closeCreateCouponModal();
            loadCoupons(); // Refresh the coupon table
        }
    })
    .catch(err => {
        console.error('Create coupon error:', err);
        alert('An error occurred. Please check the console.');
    });
}


// --- NEW: Load Stock Page ---
function loadStock() {
    const stockList = document.getElementById("stockList");
    stockList.innerHTML = "<p>Loading stock...</p>";
    
    fetch("backend/get_stock.php")
        .then(res => res.json())
        .then(stock => {
            // Check for a query error message
            if (stock.status === 'error') {
                throw new Error(stock.message);
            }
            
            stockList.innerHTML = `
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Item ID</th>
                            <th>Name</th>
                            <th>Stock Quantity</th>
                            <th>Add Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${stock.map(item => `
                            <tr class="${item.stock_quantity < 10 ? 'low-stock' : ''}">
                                <td>${item.item_id}</td>
                                <td>${item.name}</td>
                                <td>
                                    ${item.stock_quantity} 
                                    ${item.stock_quantity < 10 ? ' (Low Stock!)' : ''}
                                </td>
                                <td>
                                    <div class="stock-actions">
                                        <input type="number" class="stock-input" id="stock-add-${item.item_id}" placeholder="e.g. 50" min="1">
                                        <button class="restock-btn" onclick="restockItem(${item.item_id})">Restock</button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
        })
        .catch(err => {
            console.error("Error loading stock:", err);
            stockList.innerHTML = "<p>Error loading stock.</p>";
        });
}

// --- NEW FUNCTION TO RESTOCK ITEM ---
function restockItem(itemId) {
    const input = document.getElementById(`stock-add-${itemId}`);
    const amountToAdd = parseInt(input.value);

    if (!amountToAdd || amountToAdd <= 0) {
        alert("Please enter a positive number to add.");
        return;
    }

    if (!confirm(`Are you sure you want to add ${amountToAdd} to item #${itemId}?`)) {
        return;
    }

    fetch("backend/update_stock.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            item_id: itemId,
            amount: amountToAdd
        })
    })
    .then(res => res.json())
    .then(result => {
        alert(result.message);
        if (result.status === 'success') {
            loadStock(); // Refresh the stock list
        }
    })
    .catch(err => {
        console.error("Restock failed:", err);
        alert("An error occurred. Check the console.");
    });
}


// --- Run on Page Load ---
window.onload = () => {
    // Show dashboard by default
    showPage("dashboard");
    
    // Pre-load the menu page
    loadMenu();
};