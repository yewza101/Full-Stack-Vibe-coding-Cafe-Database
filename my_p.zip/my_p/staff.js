// Switch pages
function showPage(pageId) {
    document.querySelectorAll(".page-section").forEach(page => {
        page.classList.remove("active");
    });
    document.getElementById(pageId).classList.add("active");

    // Load data when page is shown
    if (pageId === 'orders') {
        loadOrders();
    } else if (pageId === 'stock') {
        loadStock();
    }
}

// --- Orders Page ---
function loadOrders() {
    const list = document.getElementById("ordersList");
    list.innerHTML = "<p>Loading active orders...</p>";

    fetch("backend/get_staff_orders.php")
        .then(res => res.json())
        .then(orders => {
            if (orders.length === 0) {
                list.innerHTML = "<p>No active orders found.</p>";
                return;
            }
            
            list.innerHTML = ""; // Clear list
            
            orders.forEach(order => {
                list.innerHTML += `
                    <div class="staff-card">
                        <!-- NEW: Added status tag -->
                        <span class="status-tag status-${order.order_status}">${order.order_status}</span>
                        <h3>Order #${order.order_id} (For: ${order.first_name})</h3>
                        <p><strong>Items:</strong> ${order.items}</p>

                        <div class="order-status">
                            <button class="status-btn prepare-btn" onclick="updateStatus(${order.order_id}, 'Preparing')">Preparing</button>
                            <button class="status-btn serve-btn" onclick="updateStatus(${order.order_id}, 'Serving')">Serving</button>
                            <button class="status-btn complete-btn" onclick="updateStatus(${order.order_id}, 'Complete')">Complete</button>
                        </div>
                    </div>
                `;
            });
        })
        .catch(err => {
            console.error(err);
            list.innerHTML = "<p>Error loading orders.</p>";
        });
}

function updateStatus(id, newStatus) {
    fetch("backend/update_staff_order_status.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order_id: id, status: newStatus })
    })
    .then(res => res.json())
    .then(result => {
        if (result.status === 'success') {
            loadOrders(); // Refresh the list
        } else {
            alert("Error: " + result.message);
        }
    });
}

// --- Stock Page ---
function loadStock() {
    const stockList = document.getElementById("stockList");
    stockList.innerHTML = "<p>Loading stock...</p>";
    
    // We can reuse the admin's get_stock.php file
    fetch("backend/get_stock.php")
        .then(res => res.json())
        .then(stock => {
             // Check for a query error message
            if (stock.status === 'error') {
                throw new Error(stock.message);
            }
            
            stockList.innerHTML = `
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Stock Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${stock.map(item => `
                            <tr class="${item.stock_quantity < 10 ? 'low-stock' : ''}">
                                <td>${item.name}</td>
                                <td>
                                    ${item.stock_quantity} 
                                    ${item.stock_quantity < 10 ? ' (Low Stock!)' : ''}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
        })
        .catch(err => {
            console.error("Error loading stock:", err);
            stockList.innerHTML = "<p>Error loading stock.</p>";
        });
}


// Run on page load
window.onload = () => {
    showPage("dashboard");
};