<?php
    $mysqli = new mysqli('localhost','root','root','css326_entity');
    
    // Check for connection error
    if($mysqli->connect_errno){
        // --- THIS IS THE FIX ---
        // Stop all PHP execution and output a JSON error message.
        // This prevents breaking the JavaScript.
        header('Content-Type: application/json'); // Ensure the output is JSON
        die(json_encode([
            'status' => 'error', 
            'message' => 'Database connection failed: ' . $mysqli->connect_error
        ]));
    }
?>