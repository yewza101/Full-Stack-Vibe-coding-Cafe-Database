<?php
// backend/get_users.php
header('Content-Type: application/json');
require_once '../db_connect.php';

// Get all users and their points
$sql = "SELECT User_ID, first_name, last_name, email, role, points 
        FROM users
        ORDER BY first_name ASC";

$result = $mysqli->query($sql);
$users = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
echo json_encode($users);
$mysqli->close();
?>