<?php
// backend/add_item.php

// 1. Connect to Database (Direct connection to avoid path errors)
$mysqli = new mysqli('localhost', 'root', 'root', 'css326_entity');

if ($mysqli->connect_error) {
    die("Database Connection Failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 2. Get Data from JavaScript
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $statusRaw = $_POST['status']; 

    // 3. Convert Status to Number (1 = Available, 0 = Out of Stock)
    $statusInt = ($statusRaw === "Available") ? 1 : 0;

    // 4. Insert into Database
    // Note: We are using 'menu_item' based on your SQL file
    // Note: We are NOT inserting an image because your database table doesn't have an image column yet.
    $sql = "INSERT INTO menu_item (name, category, price, stock_quantity, status) 
            VALUES (?, ?, ?, ?, ?)";
            
    $stmt = $mysqli->prepare($sql);
    
    if ($stmt) {
        // s=string, d=double, i=integer
        $stmt->bind_param("ssdis", $name, $category, $price, $stock, $statusInt);

        if ($stmt->execute()) {
            echo "Success: New item added!";
        } else {
            echo "Error adding item: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $mysqli->error;
    }
} else {
    echo "Invalid Request.";
}

$mysqli->close();
?>