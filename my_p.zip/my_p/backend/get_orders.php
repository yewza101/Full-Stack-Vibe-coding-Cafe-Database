<?php
// backend/get_orders.php
header('Content-Type: application/json');
require_once '../db_connect.php'; // Use your db_connect.php

// Join orders with users table to get the user's name
$sql = "SELECT o.order_id, o.order_date, o.total_amount, o.payment_status, o.order_status, u.first_name, u.last_name
        FROM orders o
        JOIN users u ON o.user_id = u.User_ID
        ORDER BY o.order_date DESC"; // Show newest orders first

$result = $mysqli->query($sql);
$orders = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
echo json_encode($orders);
$mysqli->close();
?>