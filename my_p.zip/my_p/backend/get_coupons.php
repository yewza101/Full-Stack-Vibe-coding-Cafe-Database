<?php
// backend/get_coupons.php
header('Content-Type: application/json');
require_once '../db_connect.php';

// Get coupons and join users to see who owns it
$sql = "SELECT c.coupon_code, c.discount_amount, c.valid_date, c.is_used, u.first_name, u.last_name
        FROM coupon c
        LEFT JOIN users u ON c.user_id = u.User_ID
        ORDER BY c.is_used ASC, c.valid_date DESC"; // Show active coupons first

$result = $mysqli->query($sql);
$coupons = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $coupons[] = $row;
    }
}
echo json_encode($coupons);
$mysqli->close();
?>