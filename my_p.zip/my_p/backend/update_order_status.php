<?php
// backend/update_order_status.php
require_once '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $order_id = $data['order_id'];
    $new_status = $data['status']; // 0 = Pending, 1 = Complete

    if (isset($order_id) && isset($new_status)) {
        $sql = "UPDATE orders SET order_status = ? WHERE order_id = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ii", $new_status, $order_id);
        
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Order status updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update status']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    }
}
$mysqli->close();
?>