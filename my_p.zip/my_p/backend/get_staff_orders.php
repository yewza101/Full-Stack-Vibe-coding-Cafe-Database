<?php
// backend/get_staff_orders.php
header('Content-Type: application/json');
require_once '../db_connect.php';

// Select all orders that are NOT "Complete"
$sql = "SELECT 
            o.order_id, 
            o.order_status, 
            u.first_name, 
            GROUP_CONCAT(CONCAT(mi.name, ' (x', od.quantity, ')') SEPARATOR ', ') AS items
        FROM orders o
        JOIN users u ON o.user_id = u.User_ID
        JOIN order_detail od ON o.order_id = od.order_id
        JOIN menu_item mi ON od.item_id = mi.item_id
        WHERE o.order_status != 'Complete'
        GROUP BY o.order_id
        ORDER BY o.order_date ASC"; // Oldest orders first

$result = $mysqli->query($sql);
$orders = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
echo json_encode($orders);
$mysqli->close();
?>