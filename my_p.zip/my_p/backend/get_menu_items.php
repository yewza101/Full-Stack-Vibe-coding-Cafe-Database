<?php
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "root", "css326_entity");
if ($conn->connect_error) {
    die(json_encode(["error" => "DB connection failed"]));
}

$sql = "SELECT * FROM menu_item";
$result = $conn->query($sql);

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

echo json_encode($items);
$conn->close();
?>
