<?php
// backend/get_user_coupons.php
header('Content-Type: application/json');

// 1. Connect to Database
$mysqli = new mysqli('localhost', 'root', 'root', 'css326_entity');
if ($mysqli->connect_error) {
    echo json_encode([]);
    exit;
}

$user_id = $_GET['user_id'] ?? 0;

if ($user_id == 0) {
    echo json_encode([]);
    exit;
}

// 2. Fetch coupons
// We use 'coupon_code' as 'code' and 'is_used' as 'used' to match the JS object
$sql = "SELECT coupon_code AS code, discount_amount AS discount, is_used AS used 
        FROM coupon 
        WHERE user_id = ?";
        
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$coupons = [];
while ($row = $result->fetch_assoc()) {
    // Convert DB types to correct JS types
    $row['discount'] = (float)$row['discount'];
    $row['used'] = (int)$row['used'];
    $coupons[] = $row;
}

echo json_encode($coupons);

$mysqli->close();
?>