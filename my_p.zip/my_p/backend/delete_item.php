<?php
$conn = new mysqli("localhost", "root", "root", "css326_entity");

if ($conn->connect_error) {
    die("Database connection failed");
}

$id = $_GET['id'];

$sql = "DELETE FROM menu_item WHERE item_id = $id";

if ($conn->query($sql)) {
    echo "Item deleted successfully!";
} else {
    echo "Failed to delete item.";
}

$conn->close();
?>
