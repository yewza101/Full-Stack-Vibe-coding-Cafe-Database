<?php
// backend/update_item.php

// 1. Connect directly (Avoids path errors with '../db_connect.php')
$mysqli = new mysqli('localhost', 'root', 'root', 'css326_entity');

// Check connection
if ($mysqli->connect_error) {
    die("Database Connection Failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 2. Get Data from JavaScript
    $id = $_POST['id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $statusRaw = $_POST['status']; 

    // 3. Convert "Available" text to 1 or 0 for the database
    $statusInt = ($statusRaw === "Available") ? 1 : 0;

    // 4. Update the Database
    // We use 'menu_item' because that is your table name in the SQL file
    $sql = "UPDATE menu_item SET 
            name = ?, 
            category = ?, 
            price = ?, 
            stock_quantity = ?, 
            status = ? 
            WHERE item_id = ?";
            
    $stmt = $mysqli->prepare($sql);
    
    if ($stmt) {
        // s=string, d=double, i=integer
        $stmt->bind_param("ssdiss", $name, $category, $price, $stock, $statusInt, $id);

        if ($stmt->execute()) {
            echo "Success: Item updated!";
        } else {
            echo "Error updating item: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $mysqli->error;
    }
} else {
    echo "Invalid Request.";
}

$mysqli->close();
?>