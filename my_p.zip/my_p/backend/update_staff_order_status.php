<?php
// backend/update_staff_order_status.php
header('Content-Type: application/json');
require_once '../db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

$order_id = $data['order_id'] ?? null;
$new_status = $data['status'] ?? null; // e.g., "Preparing", "Serving", "Complete"

if (!$order_id || !$new_status) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data.']);
    exit;
}

// Only allow specific statuses
$allowed_statuses = ['Preparing', 'Serving', 'Complete'];
if (!in_array($new_status, $allowed_statuses)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid status.']);
    exit;
}

$sql = "UPDATE orders SET order_status = ? WHERE order_id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("si", $new_status, $order_id);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Status updated to ' . $new_status]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database update failed.']);
}

$stmt->close();
$mysqli->close();
?>