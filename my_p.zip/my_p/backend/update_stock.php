<?php
// backend/update_stock.php
header('Content-Type: application/json');
require_once '../db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

$item_id = $data['item_id'] ?? null;
$amount_to_add = $data['amount'] ?? null;

if (!$item_id || !$amount_to_add || $amount_to_add <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid item ID or amount.']);
    exit;
}

$mysqli->begin_transaction();

try {
    // 1. Update the stock quantity
    $sql_update = "UPDATE menu_item SET stock_quantity = stock_quantity + ? WHERE item_id = ?";
    $stmt_update = $mysqli->prepare($sql_update);
    $stmt_update->bind_param("ii", $amount_to_add, $item_id);
    $stmt_update->execute();
    
    // 2. Log this action (based on your 'css326_entity (3).sql' file)
    $sql_log = "INSERT INTO inventory_log (item_id, quantity_change, log_date, updated_by)
                VALUES (?, ?, NOW(), 'Admin')";
    $stmt_log = $mysqli->prepare($sql_log);
    $stmt_log->bind_param("ii", $item_id, $amount_to_add);
    $stmt_log->execute();

    // If both queries succeed, commit the changes
    $mysqli->commit();
    echo json_encode(['status' => 'success', 'message' => 'Stock updated successfully!']);

} catch (Exception $e) {
    // If anything fails, roll back
    $mysqli->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Database update failed: ' . $e->getMessage()]);
}

$stmt_update->close();
$stmt_log->close();
$mysqli->close();
?>