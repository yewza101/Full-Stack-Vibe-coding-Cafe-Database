<?php
// backend/get_items.php
header('Content-Type: application/json');
require_once '../db_connect.php';

$sql = "SELECT * FROM menu_item";
$result = $mysqli->query($sql);

$items = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Convert 1 -> "Available", 0 -> "Out of Stock" before sending to JS
        $row['status'] = ($row['status'] == 1) ? "Available" : "Out of Stock";
        $items[] = $row;
    }
}

echo json_encode($items);
$mysqli->close();
?>