<?php
// backend/redeem_coupon.php
header('Content-Type: application/json');

// 1. Connect to Database
$mysqli = new mysqli('localhost', 'root', 'root', 'css326_entity');
if ($mysqli->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'DB Connection Failed']);
    exit;
}

// 2. Get Data
$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'] ?? 0;
$points_needed = $data['points'] ?? 0;
$discount_amount = $data['discount'] ?? 0;

if ($user_id === 0 || $points_needed === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data.']);
    exit;
}

$mysqli->begin_transaction();

try {
    // 3. Check if user has enough points
    $sql_check = "SELECT points FROM users WHERE user_id = ?";
    $stmt_check = $mysqli->prepare($sql_check);
    $stmt_check->bind_param("i", $user_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $user = $result->fetch_assoc();
    $current_points = $user['points'];

    if ($current_points < $points_needed) {
        throw new Exception('Insufficient points.');
    }

    // 4. Deduct points
    $new_points = $current_points - $points_needed;
    $sql_update_points = "UPDATE users SET points = ? WHERE user_id = ?";
    $stmt_update_points = $mysqli->prepare($sql_update_points);
    $stmt_update_points->bind_param("ii", $new_points, $user_id);
    $stmt_update_points->execute();

    // 5. Create new coupon
    $coupon_code = 'CYBER' . strtoupper(substr(uniqid(), 7, 6));
    $sql_create_coupon = "INSERT INTO coupon (coupon_code, discount_amount, user_id, valid_date, uses, is_used)
                          VALUES (?, ?, ?, DATE_ADD(CURDATE(), INTERVAL 30 DAY), 1, 0)";
    $stmt_create_coupon = $mysqli->prepare($sql_create_coupon);
    $stmt_create_coupon->bind_param("sdi", $coupon_code, $discount_amount, $user_id);
    $stmt_create_coupon->execute();

    // 6. Commit
    $mysqli->commit();

    // 7. Return new coupon and points
    $new_coupon = [
        'code' => $coupon_code,
        'discount' => $discount_amount,
        'used' => 0
    ];

    echo json_encode([
        'status' => 'success',
        'message' => 'Coupon redeemed!',
        'newCoupon' => $new_coupon,
        'newPoints' => $new_points
    ]);

} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

$mysqli->close();
?>