<?php
// backend/create_coupon.php
header('Content-Type: application/json');
require_once '../db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

$code = $data['code'] ?? null;
$discount = $data['discount'] ?? null;
$expiry = $data['expiry'] ?? null;

if (!$code || !$discount || !$expiry) {
    echo json_encode(['status' => 'error', 'message' => 'Please fill in all fields.']);
    exit;
}

if ($discount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Discount must be a positive number.']);
    exit;
}

try {
    // Insert the new coupon
    // We set user_id to NULL, uses to 1, and is_used to 0.
    $sql = "INSERT INTO coupon (coupon_code, discount_amount, valid_date, user_id, uses, is_used)
            VALUES (?, ?, ?, NULL, 1, 0)";
            
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("sds", $code, $discount, $expiry);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Coupon created successfully!']);
    } else {
        throw new Exception($mysqli->error);
    }

} catch (Exception $e) {
    // Check for duplicate coupon code
    if ($mysqli->errno == 1062) {
        echo json_encode(['status' => 'error', 'message' => 'Error: This coupon code already exists.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

$stmt->close();
$mysqli->close();
?>