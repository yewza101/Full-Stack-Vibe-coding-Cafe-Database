<?php
// backend/process_order.php
header('Content-Type: application/json');

// 1. Connect to Database
$mysqli = new mysqli('localhost', 'root', 'root', 'css326_entity');
if ($mysqli->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'DB Connection Failed: ' . $mysqli->connect_error]);
    exit;
}

// 2. Get Data
$data = json_decode(file_get_contents('php://input'), true);

$user_id = $data['user_id'] ?? null;
$cart = $data['cart'] ?? [];
$total = $data['total'] ?? 0;
$paymentMethod = $data['paymentMethod'] ?? 'Unknown';
$appliedCouponCode = $data['appliedCouponCode'] ?? null; // <-- NEW

if (!$user_id || empty($cart)) {
     echo json_encode(['status' => 'error', 'message' => 'Invalid data: Missing User ID or Cart.']);
    exit;
}

// 4. Start a Transaction
$mysqli->begin_transaction();

$stmt_order = null;
$stmt_detail = null;
$stmt_payment = null;
$stmt_coupon = null;
$stmt_redeem = null;
$stmt_points = null;
$stmt_get_points = null;

try {
    // --- STEP A: Insert into 'orders' table ---
    $sql_order = "INSERT INTO orders (user_id, order_date, total_amount, payment_status, order_status) 
                  VALUES (?, NOW(), ?, 1, 0)";
    $stmt_order = $mysqli->prepare($sql_order);
    $stmt_order->bind_param("id", $user_id, $total);
    $stmt_order->execute();
    $order_id = $mysqli->insert_id;
    if ($order_id == 0) throw new Exception("Failed to create order.");

    // --- STEP B: Insert into 'order_detail' ---
    $sql_detail = "INSERT INTO order_detail (order_id, item_id, quantity, subtotal) VALUES (?, ?, ?, ?)";
    $stmt_detail = $mysqli->prepare($sql_detail);
    foreach ($cart as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $stmt_detail->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $subtotal);
        $stmt_detail->execute();
    }

    // --- STEP C: Insert into 'payment' ---
    $paymentMethodInt = ($paymentMethod === 'Cash') ? 1 : 2;
    $sql_payment = "INSERT INTO payment (order_id, payment_method, payment_amount, payment_date) VALUES (?, ?, ?, NOW())";
    $stmt_payment = $mysqli->prepare($sql_payment);
    $stmt_payment->bind_param("iid", $order_id, $paymentMethodInt, $total);
    $stmt_payment->execute();

    // --- STEP D: Handle Coupon (NEW) ---
    if ($appliedCouponCode) {
        // Mark coupon as used
        $sql_coupon = "UPDATE coupon SET is_used = 1, uses = 0 WHERE coupon_code = ? AND user_id = ?";
        $stmt_coupon = $mysqli->prepare($sql_coupon);
        $stmt_coupon->bind_param("si", $appliedCouponCode, $user_id);
        $stmt_coupon->execute();

        // Get coupon_id for redemption log
        $sql_get_cid = "SELECT coupon_id FROM coupon WHERE coupon_code = ?";
        $stmt_get_cid = $mysqli->prepare($sql_get_cid);
        $stmt_get_cid->bind_param("s", $appliedCouponCode);
        $stmt_get_cid->execute();
        $cid_result = $stmt_get_cid->get_result();
        
        if ($cid_result->num_rows > 0) {
            $coupon_id = $cid_result->fetch_assoc()['coupon_id'];
            $stmt_get_cid->close();

            if($coupon_id) {
                // Log the redemption
                $sql_redeem = "INSERT INTO coupon_redemption (coupon_id, user_id, order_id, redemption_date) VALUES (?, ?, ?, NOW())";
                $stmt_redeem = $mysqli->prepare($sql_redeem);
                $stmt_redeem->bind_param("iii", $coupon_id, $user_id, $order_id);
                $stmt_redeem->execute();
            }
        } else {
             $stmt_get_cid->close();
        }
    }

    // --- STEP E: Update User Points (NEW) ---
    $pointsEarned = floor($total / 100) * 10;
    if ($pointsEarned > 0) {
        $sql_points = "UPDATE users SET points = points + ? WHERE user_id = ?";
        $stmt_points = $mysqli->prepare($sql_points);
        $stmt_points->bind_param("ii", $pointsEarned, $user_id);
        $stmt_points->execute();
    }

    // --- STEP F: Commit Transaction ---
    $mysqli->commit();

    // --- STEP G: Get new total points to send back ---
    $sql_get_points = "SELECT points FROM users WHERE user_id = ?";
    $stmt_get_points = $mysqli->prepare($sql_get_points);
    $stmt_get_points->bind_param("i", $user_id);
    $stmt_get_points->execute();
    $newPoints = $stmt_get_points->get_result()->fetch_assoc()['points'];

    echo json_encode([
        'status' => 'success', 
        'message' => 'Order processed successfully!', 
        'pointsEarned' => $pointsEarned, 
        'newTotalPoints' => (int)$newPoints
    ]);

} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Order failed: ' . $e->getMessage()]);
}

// 5. Close connections
if ($stmt_order) $stmt_order->close();
if ($stmt_detail) $stmt_detail->close();
if ($stmt_payment) $stmt_payment->close();
if ($stmt_coupon) $stmt_coupon->close();
if ($stmt_redeem) $stmt_redeem->close();
if ($stmt_points) $stmt_points->close();
if ($stmt_get_points) $stmt_get_points->close();
$mysqli->close();

?>