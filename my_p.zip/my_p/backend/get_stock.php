<?php
// backend/get_stock.php
header('Content-Type: application/json');
require_once '../db_connect.php'; // Use your good db_connect.php

// Get all items, ordered by lowest stock first
$sql = "SELECT item_id, name, stock_quantity 
        FROM menu_item
        ORDER BY stock_quantity ASC"; // Low stock items at the top

$result = $mysqli->query($sql);
$stock = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $stock[] = $row;
    }
} else {
    // If query fails, send a JSON error
    echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $mysqli->error]);
    $mysqli->close();
    exit;
}

echo json_encode($stock);
$mysqli->close();
?>