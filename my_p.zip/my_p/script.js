// Global Variables
let currentUser = null; // Will store { user_id, fname, role, points }
let userPoints = 0;
let cart = [];
let userCoupons = []; // This will be loaded from the database
let appliedCoupon = null;

// Menu Items Data (Using your existing data)
const menuItems = {
    drinks: [
        { id: 1, name: 'Cyber Berry Smoothie', price: 85, img: 'Drinks/berry.png', category: 'drink', ingredients: 'Strawberry, Blueberry, Yogurt, Ice' },
        { id: 2, name: 'Neon Latte', price: 75, img: 'Drinks/latte.jpg', category: 'drink', ingredients: 'Espresso, Milk, Butterfly Pea, Sugar' },
        { id: 3, name: 'Digital Matcha', price: 80,img: 'Drinks/matcha.avif', category: 'drink', ingredients: 'Matcha Powder, Milk, Honey' },
        { id: 4, name: 'Electric Lemonade', price: 65, img: 'Drinks/lemon.jpg', category: 'drink', ingredients: 'Lemon, Soda, Mint, Sugar' },
        { id: 5, name: 'Pixel Milkshake', price: 90, img: 'Drinks/milkshake.jpg', category: 'drink', ingredients: 'Vanilla Ice Cream, Milk, Oreo' }
    ],
    desserts: [
        { id: 6, name: 'Neon Cheese Cake', price: 120, img: 'Desserts/neon_cake.webp', category: 'dessert', ingredients: 'Cream Cheese, Graham Cracker, Berry Sauce' },
        { id: 7, name: 'Cyber Macarons', price: 95,img: 'Desserts/macaron.webp', category: 'dessert', ingredients: 'Almond Flour, Egg White, Sugar, Food Color' },
        { id: 8, name: 'Digital Donut', price: 55, img: 'Desserts/donut.jfif', category: 'dessert', ingredients: 'Flour, Sugar, Glaze, Sprinkles' },
        { id: 9, name: 'Premium Parfait', price: 85, img: 'Desserts/parfait.webp', category: 'dessert', ingredients: 'Yogurt, Granola, Mixed Berries, Honey' },
        { id: 10, name: 'Maid Special Pudding', price: 70, img: 'Desserts/pudding.jpg', category: 'dessert', ingredients: 'Milk, Egg, Sugar, Caramel' }
    ],
    food: [
        { id: 11, name: 'Digital Ramen', price: 150, img: 'Foods/food-thai-spicy-asian-162993.webp', category: 'food', ingredients: 'Noodles, Pork Broth, Egg, Green Onion, Seaweed' },
        { id: 12, name: 'Cyber Sandwich', price: 95, img: 'Foods/sandwich.jfif', category: 'food', ingredients: 'Bread, Ham, Cheese, Lettuce, Tomato' },
        { id: 13, name: 'Luxury Curry Rice', price: 130, img: 'Foods/curry.webp', category: 'food', ingredients: 'Rice, Curry Sauce, Chicken, Potato, Carrot' },
        { id: 14, name: 'Electric Pasta', price: 140,img: 'Foods/pasta.jpg', category: 'food', ingredients: 'Pasta, Cream Sauce, Bacon, Mushroom, Parmesan' },
        { id: 15, name: 'Maid Special Bento', price: 160,img: 'Foods/bento.webp', category: 'food', ingredients: 'Rice, Teriyaki Chicken, Vegetables, Egg Roll' }
    ]
};

const allMenuItems = [...menuItems.drinks, ...menuItems.desserts, ...menuItems.food];

// Page Navigation
function navigateToPage(hash) {
    document.getElementById('dashboardPage').style.display = 'none';
    document.getElementById('menuPage').style.display = 'none';
    document.getElementById('cartPage').style.display = 'none';
    document.getElementById('couponPage').style.display = 'none';
    document.getElementById('profilePage').style.display = 'none';

    switch (hash) {
        case '#menu':
            document.getElementById('menuPage').style.display = 'block';
            loadMenuItems();
            break;
        case '#cart':
            document.getElementById('cartPage').style.display = 'block';
            updateCartDisplay();
            break;
        case '#coupon':
            document.getElementById('couponPage').style.display = 'block';
            updateCouponDisplay();
            break;
        case '#profile':
            if (currentUser) {
                document.getElementById('profilePage').style.display = 'block';
                updateProfileDisplay();
            } else {
                openAuthModal();
            }
            break;
        default:
            document.getElementById('dashboardPage').style.display = 'block';
    }
}

window.addEventListener('hashchange', () => navigateToPage(window.location.hash));
window.addEventListener('load', () => navigateToPage(window.location.hash || '#dashboard'));

// Auth Modal Functions
function openAuthModal() {
    document.getElementById('authModal').classList.add('active');
}
function closeAuthModal() {
    document.getElementById('authModal').classList.remove('active');
}
function switchTab(tab) {
    const slider = document.getElementById('tabSlider');
    const loginTab = document.getElementById('loginTab');
    const signupTab = document.getElementById('signupTab');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');

    if (tab === 'login') {
        slider.classList.remove('signup');
        loginTab.classList.add('active');
        signupTab.classList.remove('active');
        loginForm.classList.add('active');
        signupForm.classList.remove('active');
    } else {
        slider.classList.add('signup');
        signupTab.classList.add('active');
        loginTab.classList.remove('active');
        signupForm.classList.add('active');
        loginForm.classList.remove('active');
    }
}

// --- UPDATED handleLogin ---
async function handleLogin() {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    if (!email || !password) return alert('Please fill in all fields');

    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);

    try {
        const response = await fetch('login.php', { method: 'POST', body: formData });
        const result = await response.json();
        alert(result.message);

        if (result.status === 'success') {
            currentUser = {
                user_id: result.user_id,
                fname: result.fname,
                name: result.fname,
                email: email,
                role: result.role
            };
            userPoints = result.points; // <-- UPDATED: Load points from DB

            updateAuthState();
            closeAuthModal();
            
            // NEW: Load user's coupons from DB
            await loadUserCoupons(currentUser.user_id);

            if (result.role === 'Admin') window.location.href = 'admin.html';
            else if (result.role === 'Staff') window.location.href = 'staff.html';
            else window.location.hash = 'dashboard';
        }
    } catch (error) {
        console.error('Login failed:', error);
        alert('Cannot connect to server.');
    }
}

async function handleSignup() {
    const fname = document.getElementById('signupfname').value.trim();
    const lname = document.getElementById('signuplname').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    const confirm = document.getElementById('signupConfirm').value; 

    if (!fname || !lname || !email || !password || !confirm) return alert('Please fill in all fields');
    if (password !== confirm) return alert('Passwords do not match');

    const formData = new FormData();
    formData.append('first_name', fname);
    formData.append('last_name', lname);
    formData.append('email', email);
    formData.append('password', password);

    try {
        const response = await fetch('signup.php', { method: 'POST', body: formData });
        const result = await response.text();
        alert(result); 

        if (result.includes('success')) {
            alert("Signup successful! Please log in to continue.");
            switchTab('login');
        }
    } catch (error) {
        console.error('Signup failed:', error);
        alert('An error occurred during signup.');
    }
}

function updateAuthState() {
    const authBtn = document.querySelector('.auth-btn');
    const profileBtn = document.getElementById('profileBtn');
    const profileName = document.getElementById('profileName');

    if (currentUser) {
        authBtn.style.display = 'none';
        profileBtn.style.display = 'flex';
        profileName.textContent = currentUser.fname;
    } else {
        authBtn.style.display = 'block';
        profileBtn.style.display = 'none';
    }
}

function logout() {
    currentUser = null;
    userPoints = 0;
    cart = [];
    userCoupons = []; // Clear local coupons
    updateAuthState();
    alert('Logout successful!');
    window.location.hash = 'dashboard';
}

// Menu Functions
function loadMenuItems(filter = 'all') {
    const menuGrid = document.getElementById('menuGrid');
    let itemsToShow = allMenuItems; 
    if (filter !== 'all') {
        itemsToShow = allMenuItems.filter(item => item.category === filter);
    }
    menuGrid.innerHTML = itemsToShow.map(item => `
        <div class="menu-card">
            <div class="menu-card-img" onclick="showItemDetail(${item.id})">
                <img src="${item.img}" alt="${item.name}">
            </div>
            <div class="menu-card-info">
                <h3>${item.name}</h3>
                <p class="price">฿${item.price}</p>
                <button class="add-to-cart-btn" onclick="addToCart(${item.id})">Add to Cart</button>
            </div>
        </div>
    `).join('');
}

function showItemDetail(itemId) {
    const item = allMenuItems.find(i => i.id === itemId);
    const modal = document.getElementById('itemModal');
    document.getElementById('itemDetail').innerHTML = `
        <div style="text-align: center;">
            <h2 style="color: var(--accent2); margin-bottom: 1rem;">${item.name}</h2>
            <p style="color: var(--accent1); font-size: 1.5rem; font-weight: bold; margin-bottom: 1rem;">฿${item.price}</p>
            <div style="background: var(--primary); padding: 1.5rem; border-radius: 10px; margin-top: 1rem;">
                <h4 style="color: var(--secondary); margin-bottom: 0.5rem;">Ingredients:</h4>
                <p style="color: var(--light);">${item.ingredients}</p>
            </div>
            <button class="add-to-cart-btn" onclick="addToCart(${item.id}); closeItemModal();">Add to Cart</button>
        </div>
    `;
    modal.classList.add('active');
}

function closeItemModal() {
    document.getElementById('itemModal').classList.remove('active');
}

function filterMenu(category) {
    loadMenuItems(category);
    toggleFilter();
}

document.addEventListener('DOMContentLoaded', () => {
    const filterToggle = document.getElementById('filterToggle');
    if (filterToggle) filterToggle.addEventListener('click', toggleFilter);
});

function toggleFilter() {
    document.getElementById('filterSidebar').classList.toggle('active');
}

// Cart Functions
function addToCart(itemId) {
    const item = allMenuItems.find(i => i.id === itemId);
    const existingItem = cart.find(i => i.id === itemId);
    if (existingItem) existingItem.quantity++;
    else cart.push({ ...item, quantity: 1 });
    alert(`Added ${item.name} to cart!`);
    updateCartDisplay();
}

function updateCartQuantity(itemId, change) {
    const item = cart.find(i => i.id === itemId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) removeFromCart(itemId);
        else updateCartDisplay();
    }
}

function removeFromCart(itemId) {
    cart = cart.filter(i => i.id !== itemId);
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cartItems');
    const subtotalEl = document.getElementById('cartSubtotal');
    const discountEl = document.getElementById('cartDiscount');
    const totalEl = document.getElementById('cartTotal');

    if (cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: var(--secondary); padding: 2rem;">Cart is empty</p>';
        subtotalEl.textContent = '฿0';
        discountEl.textContent = '฿0';
        totalEl.textContent = '฿0';
        return;
    }

    cartItems.innerHTML = cart.map((item, index) => `
        <div class="cart-item">
            <span class="cart-item-number">${index + 1}.</span>
            <span class="cart-item-name">${item.name}</span>
            <div class="cart-item-quantity">
                <button class="qty-btn" onclick="updateCartQuantity(${item.id}, -1)">-</button>
                <span>${item.quantity}</span>
                <button class="qty-btn" onclick="updateCartQuantity(${item.id}, 1)">+</button>
            </div>
            <span class="cart-item-price">฿${item.price * item.quantity}</span>
            <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
        </div>
    `).join('');

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    let discount = 0;
    
    // UPDATED: Check if applied coupon is valid
    if (appliedCoupon && appliedCoupon.used == 0) {
        discount = appliedCoupon.discount;
    } else {
        appliedCoupon = null; // Clear invalid coupon
    }

    const total = Math.max(0, subtotal - discount);

    subtotalEl.textContent = `฿${subtotal.toFixed(2)}`;
    discountEl.textContent = `฿${discount.toFixed(2)}`;
    totalEl.textContent = `฿${total.toFixed(2)}`;
}

// UPDATED: applyCoupon function
function applyCoupon() {
    const couponInput = document.getElementById('couponInput');
    const code = couponInput.value.trim().toUpperCase(); // Standardize to uppercase
    
    if (!code) return alert("Please enter a coupon code.");

    // Check the coupons loaded from the DB
    const coupon = userCoupons.find(c => c.code.toUpperCase() === code && c.used == 0);

    if (coupon) {
        appliedCoupon = coupon;
        alert(`Coupon ${code} applied! Discount ฿${coupon.discount}`);
        updateCartDisplay();
    } else {
        alert('Invalid coupon code or already used');
    }
}

function checkout() {
    if (cart.length === 0) return alert('Cart is empty');
    if (!currentUser || !currentUser.user_id) {
        alert('Please login before checkout');
        return openAuthModal();
    }
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = appliedCoupon ? appliedCoupon.discount : 0;
    const total = Math.max(0, subtotal - discount);
    openPaymentModal(total);
}

// Payment Functions
function openPaymentModal(total) {
    document.getElementById('paymentTotal').textContent = `฿${total.toFixed(2)}`;
    document.getElementById('paymentModal').classList.add('active');
}
function closePaymentModal() {
    document.getElementById('paymentModal').classList.remove('active');
}
function selectPaymentMethod(method) {
    closePaymentModal();
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = appliedCoupon ? appliedCoupon.discount : 0;
    const total = Math.max(0, subtotal - discount);

    if (method === 'cash') openCashPaymentModal(total);
    else if (method === 'credit') openCreditPaymentModal(total);
}

function openCashPaymentModal(total) {
    const modal = document.getElementById('cashPaymentModal');
    const totalEl = document.getElementById('cashTotal');
    const cashReceived = document.getElementById('cashReceived');
    const changeAmount = document.getElementById('changeAmount');

    totalEl.textContent = `฿${total.toFixed(2)}`;
    cashReceived.value = '';
    changeAmount.textContent = '฿0';

    const calculateChange = () => {
        const received = parseFloat(cashReceived.value) || 0;
        const change = received - total;
        changeAmount.textContent = `฿${change >= 0 ? change.toFixed(2) : '0.00'}`;
    };
    cashReceived.removeEventListener('input', calculateChange); // Prevent duplicates
    cashReceived.addEventListener('input', calculateChange);
    modal.classList.add('active');
}
function closeCashPaymentModal() {
    document.getElementById('cashPaymentModal').classList.remove('active');
}
async function processCashPayment() {
    const cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = appliedCoupon ? appliedCoupon.discount : 0;
    const total = Math.max(0, subtotal - discount);

    if (cashReceived < total) return alert('Insufficient amount');
    
    const change = cashReceived - total;
    closeCashPaymentModal();
    await completePayment('Cash', total, change);
}

function openCreditPaymentModal(total) {
    const modal = document.getElementById('creditPaymentModal');
    document.getElementById('creditTotal').textContent = `฿${total.toFixed(2)}`;
    document.getElementById('cardNumber').value = '';
    document.getElementById('cardName').value = '';
    document.getElementById('cardExpiry').value = '';
    document.getElementById('cardCVV').value = '';
    modal.classList.add('active');
    
    // Removed and re-added listeners to prevent duplicates
    const cardNumberInput = document.getElementById('cardNumber');
    const formatCardNumber = (e) => {
        let value = e.target.value.replace(/\s/g, '');
        e.target.value = value.match(/.{1,4}/g)?.join(' ') || value;
    };
    cardNumberInput.removeEventListener('input', formatCardNumber);
    cardNumberInput.addEventListener('input', formatCardNumber);

    const expiryInput = document.getElementById('cardExpiry');
    const formatExpiry = (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length >= 2) value = value.slice(0, 2) + '/' + value.slice(2, 4);
        e.target.value = value;
    };
    expiryInput.removeEventListener('input', formatExpiry);
    expiryInput.addEventListener('input', formatExpiry);
}
function closeCreditPaymentModal() {
    document.getElementById('creditPaymentModal').classList.remove('active');
}
async function processCreditPayment() {
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
    const cardName = document.getElementById('cardName').value.trim();
    const cardExpiry = document.getElementById('cardExpiry').value;
    const cardCVV = document.getElementById('cardCVV').value;

    if (!cardNumber || !cardName || !cardExpiry || !cardCVV) return alert('Please fill in all fields');
    if (cardNumber.length !== 16) return alert('Invalid card number (must be 16 digits)');
    if (cardCVV.length !== 3) return alert('Invalid CVV (must be 3 digits)');
    if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(cardExpiry)) return alert('Invalid expiry date (format MM/YY)');
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = appliedCoupon ? appliedCoupon.discount : 0;
    const total = Math.max(0, subtotal - discount);

    closeCreditPaymentModal();
    alert('Processing payment...');

    setTimeout(async () => {
        await completePayment('Credit Card', total, 0);
    }, 1500);
}

// --- UPDATED completePayment function ---
async function completePayment(paymentMethod, total, change = 0) {
    
    // 1. Prepare order data
    const orderData = {
        user_id: currentUser.user_id,
        cart: cart,
        total: total,
        paymentMethod: paymentMethod,
        appliedCouponCode: appliedCoupon ? appliedCoupon.code : null // <-- NEW: Send coupon code
    };

    try {
        // 2. Send the order to the backend
        const response = await fetch('backend/process_order.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(orderData)
        });

        const result = await response.json();

        if (result.status === 'success') {
            // 3. Update local points from DB response
            userPoints = result.newTotalPoints; // <-- NEW
            
            if (appliedCoupon) {
                // Find the local coupon and mark it as used
                const couponInList = userCoupons.find(c => c.code === appliedCoupon.code);
                if(couponInList) couponInList.used = 1;
                
                appliedCoupon = null;
            }

            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const discount = subtotal - total;

            showReceipt(cart, subtotal, discount, total, result.pointsEarned, paymentMethod, change); // <-- NEW: Use pointsEarned from result

            // 4. Clear cart
            cart = [];
            updateCartDisplay();
            updateCouponDisplay(); // Update display with new points
        } else {
            alert("Error: Could not process order.\n" + result.message);
        }
    } catch (error) {
        console.error("Payment Error:", error);
        alert("A critical error occurred. Please contact support.");
    }
}

function showReceipt(items, subtotal, discount, total, pointsEarned, paymentMethod, change) {
    const modal = document.getElementById('receiptModal');
    const now = new Date();
    document.getElementById('receiptContent').innerHTML = `
        <div class="receipt">
            <h2>🤖 Cyber Maid Cafe</h2>
            <p style="text-align: center; margin-bottom: 1rem;">Receipt</p>
            <p style="text-align: center; margin-bottom: 1rem;">${now.toLocaleDateString('en-GB')} ${now.toLocaleTimeString('en-GB')}</p>
            
            <div class="receipt-items">
                ${items.map((item, index) => `
                    <div class="receipt-item">
                        <span>${index + 1}. ${item.name} x${item.quantity}</span>
                        <span>฿${(item.price * item.quantity).toFixed(2)}</span>
                    </div>`).join('')}
            </div>

            <div class="receipt-item"><span>Subtotal:</span> <span>฿${subtotal.toFixed(2)}</span></div>
            ${discount > 0 ? `<div class="receipt-item" style="color: var(--accent1);"><span>Discount:</span> <span>-฿${discount.toFixed(2)}</span></div>` : ''}
            <div class="receipt-total">Total: ฿${total.toFixed(2)}</div>

            <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 2px dashed #ccc;">
                <p style="text-align: center; margin-bottom: 0.5rem;"><strong>Payment Method: ${paymentMethod}</strong></p>
                ${change > 0 ? `<p style="text-align: center; color: var(--accent2);">Change: ฿${change.toFixed(2)}</p>` : ''}
            </div>

            <p style="text-align: center; margin-top: 2rem; color: var(--accent1); font-weight: bold;">
                🎉 You earned ${pointsEarned} points! 🎉
            </p>
            <p style="text-align: center; margin-top: 0.5rem;">Thank you for your patronage ✨</p>
        </div>
    `;
    modal.classList.add('active');
}

function closeReceiptModal() {
    document.getElementById('receiptModal').classList.remove('active');
}

// --- NEW function to load coupons from DB ---
async function loadUserCoupons(userId) {
    if (!userId) return;
    try {
        const response = await fetch(`backend/get_user_coupons.php?user_id=${userId}`);
        const coupons = await response.json();
        userCoupons = coupons; // Load coupons from DB into global array
        updateUserCouponList(); // Update the UI
    } catch (error) {
        console.error("Failed to load coupons:", error);
    }
}

// --- UPDATED Coupon Functions ---
function updateCouponDisplay() {
    // Update points display
    document.getElementById('currentPoints').textContent = userPoints;
    document.getElementById('profilePoints').textContent = userPoints;
    
    const percentage = Math.min((userPoints / 100) * 100, 100);
    document.getElementById('pointsBar').style.width = percentage + '%';
    document.getElementById('pointsText').textContent = `${userPoints} / 100`;

    // Update buttons
    document.getElementById('coupon25').disabled = userPoints < 25;
    document.getElementById('coupon50').disabled = userPoints < 50;
    document.getElementById('coupon100').disabled = userPoints < 100;

    updateUserCouponList();
}

// --- UPDATED redeemCoupon function ---
async function redeemCoupon(points, discount) {
    if (!currentUser) return alert('Please login first');
    if (userPoints < points) return alert('Insufficient points');

    try {
        const response = await fetch('backend/redeem_coupon.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                user_id: currentUser.user_id,
                points: points,
                discount: discount
            })
        });

        const result = await response.json();
        alert(result.message);

        if (result.status === 'success') {
            userCoupons.push(result.newCoupon); // Add new coupon to local array
            userPoints = result.newPoints; // Update local points
            updateCouponDisplay(); // Refresh UI
        }
    } catch (error) {
        console.error("Redeem failed:", error);
        alert("Redemption failed. Please try again.");
    }
}

function updateUserCouponList() {
    const couponList = document.getElementById('couponList');
    // Filter for coupons that are not used (used == 0)
    const availableCoupons = userCoupons.filter(c => c.used == 0);

    if (availableCoupons.length === 0) {
        couponList.innerHTML = '<p style="text-align: center; color: var(--secondary);">No available coupons</p>';
        return;
    }

    couponList.innerHTML = availableCoupons.map(coupon => `
        <div class="user-coupon-item">
            <div>
                <strong style="color: var(--accent1);">${coupon.code}</strong>
                <p style="color: var(--light);">Discount ฿${coupon.discount}</p>
            </div>
            <span style="color: var(--accent2);">Available</span>
        </div>
    `).join('');
}

// Profile Functions
function updateProfileDisplay() {
    if (currentUser) {
        document.getElementById('profileDisplayName').textContent = currentUser.name;
        document.getElementById('profileDisplayEmail').textContent = currentUser.email;
        document.getElementById('profilePoints').textContent = userPoints; // Use global var
    }
}

// Initialize
updateAuthState();